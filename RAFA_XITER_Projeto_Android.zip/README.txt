RAFA XITER - PROJETO ANDROID

Este projeto transforma o painel HTML em um app Android simples, com ícone RX neon.
O projeto fonte ainda precisa ser compilado para produzir o arquivo APK.

COMO GERAR O APK PELO CELULAR (GitHub Actions):
1. Extraia este ZIP.
2. Entre em https://github.com/ e crie uma conta/entre na conta.
3. Crie um repositório novo chamado RafaXiter. Pode ser Public ou Private.
4. Envie os arquivos e pastas extraídos mantendo a estrutura. O arquivo .github/workflows/build-apk.yml precisa ser incluído.
5. Abra a aba Actions do repositório e selecione "Build RAFA XITER APK".
6. Toque em "Run workflow" se o fluxo não iniciar sozinho.
7. Quando terminar com sucesso, abra a execução concluída, procure Artifacts e baixe "RAFA-XITER-APK".
8. Extraia o ZIP baixado; dentro dele estará app-debug.apk. Toque nele para instalar no Android.

OBSERVAÇÕES:
- O APK gerado é uma versão de teste/debug para instalação pessoal, não uma versão publicada na Play Store.
- O Android pode pedir autorização para instalar apps dessa fonte.
- Este app abre o HTML localmente; as funções do painel são apenas interface visual demonstrativa e não se conectam a jogos.
